// Modal for win
let modal= document.querySelector(".modal-container");
// Enemies our player must avoid
// Enemy class
var Enemy = function(x, y) {
    this.sprite = 'images/enemy-bug.png';
    this.x=x;
    this.y=y;
    this.arg1=x;
    this.arg2=y; 
     
};

// Update the enemy's position, required method for game
// Parameter: dt, a time delta between ticks
Enemy.prototype.update = function(dt) {
    
    for(let i=0; i<allEnemies.length; i++){
            allEnemies[i].speed=150;
        }
    
    // You should multiply any movement by the dt parameter
    // which will ensure the game runs at the same speed for
    // all computers.
    this.x = this.x+(this.speed*dt);
    
    //reset enemy's position
    if( this.x >= 500 ){
        this.reset();
    }
    
    //handling collision with the enemies
    if( player.x >= this.x -40 && player.x <=this.x + 40 ){
        if( player.y >= this.y -40 && player.y <=  this.y+40 ){
            player.x = 200;
            player.y = 400;
        }
    }
};

// reset the enemy
Enemy.prototype.reset = function(){
    this.x = this.arg1;
    this.y = this.arg2;
};

// Draw the enemy on the screen, required method for game
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Now write your own player class
// This class requires an update(), render() and
// a handleInput() method.
function Player(x,y){
    this.sprite = 'images/char-horn-girl.png';
    this.x=x;
    this.y=y;
};

Player.prototype.update = function(dt) {
    if( this.y < -18 ){
        modal.classList.add("show");    }    
};

// Draw the player on the screen, required method for game
Player.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// Method that receive user input and move the player according to that input
Player.prototype.handleInput = function(prs) {
    if( prs === 'left' && this.x > 0 )  
        this.x = this.x - 20;
    else if( prs === 'right' && this.x < 400)
        this.x = this.x + 20;
    else if( prs === 'up' && this.y > -50)
        this.y = this.y - 30;
    else if( prs === 'down' && this.y < 400)
        this.y = this.y + 20;
};

Player.prototype.reset = function(){
    this.x = 200;
    this.y = 400;
};


// Now instantiate your objects.
// Place all enemy objects in an array called allEnemies
// Place the player object in a variable called player
let enemy1= new Enemy(-100, 60);
let enemy2= new Enemy(-500, 120);
let enemy3= new Enemy(-180, 220);
let enemy4= new Enemy(-400,140);
let enemy5= new Enemy(-280,80);
let enemy6= new Enemy(-210,300);
let enemy7= new Enemy(-300, 200);
let enemy8= new Enemy(-300, 150);

let allEnemies= [enemy1, enemy2, enemy3, enemy4, enemy5, enemy6, enemy7, enemy8];

let player =new Player(200, 440);

// This listens for key presses and sends the keys to your
// Player.handleInput() method. You don't need to modify this.
document.addEventListener('keyup', function(e) {
    let allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});


function closeModal(){
        modal.classList.remove("show");
        reset();
}
function playAgain(){
    modal.classList.remove("show");
    reset();
}
