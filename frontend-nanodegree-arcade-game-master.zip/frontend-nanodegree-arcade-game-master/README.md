# Classic Arcade Game Clone Project

## Table of Contents
- [Introduction](#introduction)
- [Instructions](#instructions)

## Introduction
In this game you have a Player and Enemies (bugs). The goal of the player is to reach the water, without colliding into any one of the enemies.

## Instructions
When the start game, you will see player and Enemies.
The player can move left, right, up and down.
Player must cross the stone to arrive the water without collision with enemies. 
Once a the player collides with an enemy, the game is reset and the player moves back to the starting square
Once the player reaches the water, the game is won

